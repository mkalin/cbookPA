#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>

/** alternative way to set non-blocking **/
unsigned set_nonblock(int fd) {
  int flags = fcntl(fd, F_GETFL);          /* get the current flag values */
  if (-1 == flags) return 0;               /* on error, return false */
  flags |= O_NONBLOCK;                     /* add non-blocking */
  return -1 != fcntl(fd, F_SETFL, flags);  /* true (1) == success, false (0) == failure */
}

unsigned is_prime(unsigned n) { /* not pretty, but gets the job done efficiently */
  if (n <= 3) return n > 1;
  if (0 == (n % 2) || 0 == (n % 3)) return 0;

  unsigned i;
  for (i = 5; (i * i) <= n; i += 6)
    if (0 == (n % i) || 0 == (n % (i + 2))) return 0;
  return 1;
}

int main() {
  const char* file = "./fifoChannel";
  int fd = open(file, O_RDONLY | O_NONBLOCK); /* non-blocking */
  if (fd < 0) return; /* no point in continuing */
  unsigned primes_count = 0, success = 0, failure = 0;

  while (1) {
    int next;
    int i;
    ssize_t count = read(fd, &next, sizeof(int));

    if (0 == count) break;                  /* end of stream */
    else if (count == sizeof(int)) {        /* read a 4-byte int value */
      success++;
      if (is_prime(next)) primes_count++;
    }
    else                                    /* includes errors, and < 4 bytes read */
      failure++;
  }

  close(fd);       /* close pipe from read end */
  unlink(file);    /* unlink from the underlying file */
  printf("Success: %u\tPrimes: %u\tFailure: %u\n", success, primes_count, failure);

  return 0;
}
