#include <stdio.h>
#include <fcntl.h>
#define BuffSize 5 /* number of ints stored in nums.dat */

int main() {
  const char* file = "nums.dat";  /* produced by the sysWrite program */
  FILE* fptr = fopen(file, "r");
  if (!fptr) return;

  int buffer[BuffSize]; 
  if (fread(buffer, sizeof(int), BuffSize, fptr) < BuffSize) 
    puts("Error on fread...");
  else {
    int i;
    for (i = 0; i < BuffSize; i++) printf("%i\n", buffer[i]);
  }
  fclose(fptr);
  int fd = open("nums.dat", O_RDONLY);
  read(fd, buffer, sizeof(int) * BuffSize);
  int i;
  for (i = 0; i < BuffSize; i++) printf("%i\n", buffer[i]);

  return 0;
}
