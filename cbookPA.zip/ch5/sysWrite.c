#include <unistd.h>
#include <fcntl.h>

#define FILE_NAME "nums.dat"

int main() {
  /* Open a file for reading and writing. */
  int fd = open(FILE_NAME,                    /* name */
                O_CREAT | O_RDWR,             /* create, read/write */
                S_IRUSR | S_IWUSR | S_IXUSR | /* owner's rights */
                S_IROTH | S_IWOTH | S_IXOTH); /* others' rights */
  if (fd < 0) { /* -1 on error, positive value on success */
    perror(NULL);
    return;
  }

  /* Write some data. */
  int nums[ ] = {9, 7, 5, 3, 1}; /* int[ ] type */
  ssize_t flag = write(fd, nums, sizeof(nums));
  if (flag < 0) { /* -1 on error, count of written bytes on success */
    perror(NULL);
    return;
  }

  /* Close the file. */
  flag = close(fd);
  if (flag < 0) perror(NULL);

  return 0;
}
