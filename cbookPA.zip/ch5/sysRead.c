#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>

#define FILE_NAME "nums.dat"

int main() {
  int fd = open(FILE_NAME, O_RDONLY); /* open for reading only */
  if (fd < 0) { /* -1 on error, > 2 on success */
    perror(NULL);  /* "No such file or directory" if nums.dat doesn't exist */
    return;
  }

  int read_in[5]; /* buffer to hold the bytes */
  ssize_t how_many = read(fd, read_in, sizeof(read_in));
  if (how_many < 0) {
    perror(NULL);
    return;
  }
  close(fd); /* no error check this time */

  int i;
  int n = how_many / sizeof(int); /* from byte count to number of ints */
  for (i = 0; i < n; i++) printf("%i\n", read_in[i] * 10); /* 90 70 50 30 10 */

  return 0;
}
