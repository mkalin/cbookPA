#include <string.h>
#include <unistd.h>
#include <fcntl.h>

#define FILE_NAME "test.dat"

int main()  {
  const char* bytes = "abcdefghijklmnopqrstuvwxyz";
  int len = strlen(bytes);
  char buffer[len / 2];
  char big_N = 'N';

  /* Open the file and populate it with some bytes. */
  int fd = open(FILE_NAME,
                O_RDWR | O_CREAT,             /* flags */
                S_IRUSR | S_IWUSR | S_IXUSR); /* owner's rights */
  write(fd, bytes, len);

  off_t offset = len / 2;            /* twelve bytes in is character n */
  lseek(fd, offset, SEEK_SET);       /* SEEK_SET is the start of the file */
  write(fd, &big_N, sizeof(char));   /* overwrite 'n' with 'N' */
  close(fd);

  fd = open(FILE_NAME, O_RDONLY);    /* reopen the file */
  lseek(fd, offset, SEEK_SET);       /* seek the position of letter N */
  read(fd, buffer, len / 2);         /* read from this position */
  close(fd);

  write(1, buffer, len / 2);  /* Nopqrstuvwxyz */
  putchar('\n');
  return 0;
}
