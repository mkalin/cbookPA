#include <unistd.h>
#include <string.h>

#define BuffSize 4

void main() {
  const char* prompt = "Four characters, please: ";
  char buffer[BuffSize];  /* 4-byte buffer */

  /* write returns -1 on error, count of bytes written on success */
  write(STDOUT_FILENO, prompt, strlen(prompt));
  ssize_t flag = read(0, buffer, sizeof(buffer));  /* 0 == stdin */

  if (flag < 0)
    perror("Ooops...");  /* this string + a system msg explaining errno */
  else
    write(1, buffer, sizeof(buffer));              /* 1 == stdout */
  putchar('\n');
}
