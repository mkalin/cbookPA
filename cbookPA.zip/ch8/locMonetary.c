#include <locale.h>
#include <stdio.h>
#include <stdlib.h>

int main () {
  setlocale(LC_ALL, ""); /* set all categories to default locale */
  char* regions[ ] = {"en_AU.utf-8", "en_CA.utf-8", "en_GB.utf-8",
                      "en_US.utf-8", "en_NZ.utf-8", "en_ZM.utf-8", NULL};
  int i = 0;
  while (regions[i]) {
    setlocale(LC_MONETARY, regions[i]);     /* change the locale */
    const struct lconv* loc = localeconv(); /* refresh */
    printf("Region: %s   Currency symbol: %s   International currency symbol: %s\n",
           regions[i], loc->currency_symbol, loc->int_curr_symbol);
    i++;
  }
  return 0;
}
