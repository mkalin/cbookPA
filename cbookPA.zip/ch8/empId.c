#include <stdio.h>
#include <regex.h>

#define MaxBuffer 64

int main() {
  char input[MaxBuffer];
  char error[MaxBuffer + 1]; /* null terminator */
  printf("Employee Id: ");
  scanf("%7s", input);       /* read only 7 chars */

  const char* regex = "^[A-Z]{2}[1-9]{3}[a-k]{2}$"; /* regex as a string */
  regex_t regex_comp;
  int flag;
  if ((flag = regcomp(&regex_comp, regex, REG_EXTENDED)) < 0) { /* compile regex */
    regerror(flag, &regex_comp, error, MaxBuffer);
    fprintf(stderr, "Error compiling '%s': %s\n", regex, error);
    return;
  }

  if (REG_NOMATCH == regexec(&regex_comp, input, 0, NULL, 0))    /* match? */
    fprintf(stderr, "\n%s is an invalid employee ID.\n", input);
  else
    fprintf(stderr, "\n%s is a valid employee ID.\n", input);
  regfree(&regex_comp); /* good idea to clean up */

  return 0;
}
