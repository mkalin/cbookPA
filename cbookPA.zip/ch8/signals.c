#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

#define MaxLoops 500

void cntrlC_handler(int signum) {  /** callback function: int arg, void return **/
  fprintf(stderr, "\n\tHandling signal %i\n", signum);
  int ans = 1;
  printf("Sure you want to exit (1 = yes, 0 = no)? ");
  scanf("%i", &ans);
  if (1 == ans) exit(EXIT_SUCCESS);
}

int main() {
  /** Set up a signal handler. **/
  struct sigaction current;
  sigemptyset(&current.sa_mask);        /* clear the signal set */
  current.sa_flags = 0;                 /* enables setting sa_handler, not sa_action */
  current.sa_handler = cntrlC_handler;  /* specify a handler */
  sigaction(SIGINT, &current, NULL);    /* control-C is a SIGINT */

  int i;
  for (i = 0; i < MaxLoops; i++) {
    printf("Counting sheep %i...\n", i + 1);
    sleep(1);
  }
  return 0;
}
