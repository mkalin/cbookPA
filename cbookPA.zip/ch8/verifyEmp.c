#include <stdio.h>
#include <regex.h>
#include <assert.h>

#define MaxBuffer 64
#define MaxTries   3

unsigned check_id(const char* id, regex_t* regex) {
  return REG_NOMATCH != regexec(regex, id, 0, NULL, 0);
}

int main() {
  const char* regex_s = "^[A-Z]{2,4}[1-9]{3}[a-k]{2}[0-1]?$"; 
  regex_t regex_c;
  if (regcomp(&regex_c, regex_s, REG_EXTENDED) < 0) {
    fprintf(stderr, "Bad regex. Exiting.\n");
    return;
  }

  char id[MaxBuffer];
  unsigned tries = 0, flag = 0;

  assert(0 == tries);                  /* precondition */
  do {
    assert(tries < MaxTries);          /* invariant */

    printf("Employee Id: ");
    scanf("%10s", id);   
    if (check_id(id, &regex_c)) {
      flag = 1;
      break;
    }
    tries++;
  } while (tries < MaxTries);

  assert(tries <= MaxTries);           /* postcondition */

  regfree(&regex_c); /* clean up */
  if (flag) printf("%s verified.\n", id);
  else printf("%s not verified.\n", id);  

  return 0;
}
