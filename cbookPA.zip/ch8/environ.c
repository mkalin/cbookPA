#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

extern char** environ; /* declaration */

int main () {
  int i = 0;
  while (environ[i]) printf("%s\n", environ[i++]);
  printf("Locale: %s\n", getenv("LANG"));      /* en_US.UTF-8 */

  char cmd[32];
  strcpy(cmd, "locale -a");
  int status = system(cmd);
  printf("\n%s exited with %i\n", cmd, status);

  return 0;
}
