#include <stdio.h>

int main() {
  int n = 1234;
  int* ptr1 = &n;         /* ptr1----->n */
  int** ptr2 = &ptr1;     /* ptr2----->ptr1 */
  printf("%i  %p  %p\n", n, ptr1, ptr2); /* 1234  0x7ffee80dfb5c  0x7ffee80dfb60 */

  **ptr2 = *ptr1 + 100;   /* increment n by 100 */
  printf("%i %i %i\n", n, *ptr1, **ptr2); /* 1334 1334 1334 */

  return 0;
}
