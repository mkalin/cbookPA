#include <stdio.h>
#include <limits.h>

int mult_overflow(int n1, int n2, int* product) {
  int flag = 0;         /* assume no overflow */
  *product = n1 * n2;   /* potential overflow */

  asm("setae %%bl; movzbl %%bl,%0"
      : "=r" (flag)          /* set flag on overflow */
      :                      /* no other inputs  */
      : "%rbx");             /* scratchpad */
  return flag;  /* zero is no overflow, non-zero is overflow */
}

int main() {
  int n;
  char* msg;
  int flag = mult_overflow(16, 48, &n);
  msg =  (!flag) ? "Overflow on 16 * 48" : "No overflow on 16 * 48";
  printf("%s: returned product == %i\n", msg, n);

  flag = mult_overflow(INT_MAX, INT_MAX, &n);
  msg = (!flag) ? "Overflow on INT_MAX * INT_MAX" : "No overflow on INT_MAX * INT_MAX";
  printf("%s: returned product == %i\n", msg, n);

  return 0;
}
