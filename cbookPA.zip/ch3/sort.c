#include <stdio.h>
#include <stdlib.h> /* rand, qsort */

#define Size 12

void print_array(int* array, unsigned n) {
  unsigned i;
  for (i = 0; i < n; i++) printf("%i ", array[i]);
  printf("\n");
}

int comp(const void* p1, const void* p2) {
  int n1 = *((int*) p1); /* cast p1 to int*, then dereference */
  int n2 = *((int*) p2); /* same for p2 */
  return n2 - n1;        /* descending order */
}

int main() {
  int arr[Size], i;
  for (i = 0; i < Size; i++) arr[i] = rand() % 100; /* values < 100 */
  print_array(arr, Size); /* 83 86 77 15 93 35 84 92 49 21 62 27 */

  qsort(arr, Size, sizeof(int), comp); /* comp is a pointer to a function */
  print_array(arr, Size); /* 93 92 86 84 83 77 62 49 35 27 21 15 */

  return 0;
}
