#include <stdio.h>

#define Size 8

int main() {
  int arr[Size];              /* storage from the stack -- uninitialized */
  int i;
  for (i = 0; i < Size; i++)  /* iterate over the array */
    arr[i] = i + 1;           /* assign a value to each element */
  for (i = 0; i < Size; i++)
    printf("%i\n", arr[i]);

  printf("Array's size: %lu\n", sizeof(arr));

  return 0;
}
