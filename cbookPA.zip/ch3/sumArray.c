#include <stdio.h>

#define Size 9

int sum_array(int arr[], unsigned n) {
  int sum = 0;
  unsigned i;
  for (i = 0; i < n; i++) sum += arr[i];
  return sum;
}

int main() {
  int nums[ ] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
  int n = sum_array(nums, Size);
  printf("The sum is: %i\n", n); /* The sum is: 45 */

  return 0;
}
