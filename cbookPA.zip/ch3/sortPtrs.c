#include <stdio.h>
#include <stdlib.h> /* rand */

#define SizeS  1000
#define SizeA   100

typedef struct {
  double nums[SizeS];  /* 8 bytes per */
  int    n;            /* for demo purposes */
} BigNumsStruct;

int comp(const void* p1, const void* p2) {
  BigNumsStruct* ptr1 = *((BigNumsStruct**) p1); /* p1 points to a pointer */
  BigNumsStruct* ptr2 = *((BigNumsStruct**) p2); /* p2 points to a pointer */
  return ptr1->n - ptr2->n;                      /* ascending order */
}

int main() {
  BigNumsStruct big_nums[SizeA]; 
  BigNumsStruct* pointers[SizeA];
  int i;

  for (i = 0; i < SizeA; i++) {
    big_nums[i].n = rand();     
    pointers[i] = big_nums + i; /* base address (big_nums) plus offset (index i) */
  }

  qsort(pointers, SizeA, sizeof(BigNumsStruct*), comp); /** sort the pointers **/
  for (i = 0; i < SizeA; i++) printf("%i\n", pointers[i]->n);

  return 0;
}
