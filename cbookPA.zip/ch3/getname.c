#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BuffSize 128

void get_name1(char buffer[ ], size_t len) {  /* safest: buffer passed in as arg */
  strncpy(buffer, "Gandalf", len);            /* user-supplied buffer */
}

void* get_name2() {                           /* ok, but invoker must free */
  void* ptr = malloc(BuffSize + 1);
  if (!ptr) return 0;
  strncpy(ptr, "Sam", BuffSize);              /* at most BuffSize characters */
  return ptr;               
}

char* get_name3() {                           /* VERY BAD (compiler warning) */
  char buffer[BuffSize + 1];
  strncpy(buffer, "Frodo", BuffSize);         /* at most BuffSize characters */
  return buffer; 
}

/** headers and macro above **/
int main() {
  char buffer[BuffSize + 1];         /* + 1 for null terminator */
  get_name1(buffer, BuffSize);
  printf("%s\n", buffer);

  void* retval2 = get_name2();
  printf("%s\n", (char*) retval2);   /* cast for the %s */
  free(retval2);                     /* safeguard against memory leak */

  const char* retval1 = get_name3(); /* not a good idea */
  printf("%s\n", retval1);           /* unpredictable output */

  return 0;
}

