#include <stdio.h>

void print(int (*arr)[4], int n) {
  int i, j;
  for (i = 0; i < n; i++)
    for (j = 0; j < 4; j++)
      printf("%i ", arr[i][j]);
  printf("\n");
}

int main() {
  int table[3][4] = {{1, 2, 3, 4}, {9, 8, 7, 6}, {3, 5, 7, 9}};
  int i, j;

  for (i = 0; i < 3; i++)           /** outer loop: 3 rows **/
    for (j = 0; j < 4; j++)         /** inner loop: 4 cols per row **/
      printf("%i ", table[i][j]);
  printf("\n");

  int* ptr = (int*) table;          /** ptr points to an int **/
  for (i = 0; i < 12; i++)          /** 12 ints in all (3 rows, 4 cols each) **/
    printf("%i ", ptr[i]);
  printf("\n");
  print(table, 3);

  return 0;
}
