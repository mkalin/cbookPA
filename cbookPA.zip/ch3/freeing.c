#include <stdio.h>
#include <stdlib.h>

typedef struct {
  int x;
  int y;
} XYPair;

typedef struct {
  XYPair*  pairs;
  unsigned size;
} CoordList;

CoordList* make_list(unsigned size) {  /** nested allocation **/
  XYPair* pairs = calloc(size, sizeof(XYPair));
  if (!pairs) return NULL;

  CoordList* list = malloc(sizeof(CoordList));
  if (!list) {
    free(pairs);  /* clean this up first, from successful calloc above */
    return NULL;
  }

  list->pairs = pairs;
  list->size = size;
  return list;
}

void free_list(CoordList* list) { /** nested freeing **/
  if (!list) return;
  free(list->pairs);      /* free anything that's been malloced/calloced */
  free(list);             /* the list container */
}

int main() {
  const int n = 100;
  CoordList* list = make_list(n);    /* dynamically allocated list of 100 */

  int i;
  for (i = 0; i < n; i++) {          /* do some simple app logic */
    list->pairs[i].x = i + 1;
    list->pairs[i].y = -(i + 1);
  }

  for (i = 0; i < n; i++)            /* confirm assignments */
    printf("x: %4i     y: %4i\n", list->pairs[i].x, list->pairs[i].y);
  free_list(list);                   /** do a nested free on the list **/

  return 0;
}
