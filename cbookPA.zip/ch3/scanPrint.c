#include <stdio.h>

int main() {
  char* s1 = "123456";
  char* s2 = "123.45";
  int n1;
  float n2;

  /** string to other types: sscanf **/
  sscanf(s1, "%i", &n1); /* address of n1, not n1 */
  sscanf(s2, "%f", &n2); /* address of n2, not n2 */
  printf("%i %f\n", n1 + 3, n2 + 8.7f); /* 123459 132.149994 */

  /** other types to string: sprintf **/
  char buffer[64]; /* actual storage on the stack, not just a pointer */
  sprintf(buffer, "%i", n1 + 3);
  printf("%s\n", buffer); /* 123459 */

  return 0;
}
