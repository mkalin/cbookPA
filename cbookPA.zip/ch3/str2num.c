#include <stdio.h>
#include <stdlib.h> /* atoi, etc. */

int main() {
  const char* s1 = "27";
  const char* s2 = "27.99";
  const char* s3 = "    123";     /* whitespace to begin */
  const char* e1 = "1z2q";        /* bad characters */
  const char* e2 = "4m3.abc!#";   /* ditto */

  printf("%s + 3 is %i.\n",      s1, atoi(s1) + 3);   /* 27 + 3 is 30. */
  printf("%s + 3 is %f.\n",      s2, atof(s2) + 3.0); /* 27.99 + 3 is 30.990000. */
  printf("%s to int is %i.\n",   s3, atoi(s3));       /*     123 to int is 123. */
  printf("%s to int is %i.\n",   e1, atoi(e1));       /* 1z2q to int is 1. */
  printf("%s to float is %f.\n", e2, atof(e2));       /* 4m3.abc to float is 4.000000. */

  char* bad_chars = NULL;
  const char* e3 = "9876 !!foo bar";
  long num = strtol(e3, &bad_chars, 10);              /* 10 is the base, for decimal */
  printf("Number: %li\tJunk: %s\n", num, bad_chars);  /* Number: 9876   Junk:  !!foo bar */

  return 0;
}
