#include <stdio.h>

#define Size 8

int main() {
  int arr[Size];               /* storage from the stack -- uninitialized */
  int k = 1;
  int* ptr = arr;              /* point to the start of the array */
  int* end = arr + Size;       /* points immediately beyond the end of the array */

  while (ptr < end) {          /* at the end yet? */
    *ptr = k++;                /* assign a value to the array element */
    ptr++;                     /* increment the pointer */
  }

  int i;
  for (i = 0; i < Size; i++)
    printf("%i\n", arr[i]);

  return 0;
}
