#include <stdio.h>

/* definition of the extern variable: keyword extern is absent, but
   could be present if the variable were initialized in its definition,
   but a compiler warning would result. */
int global_num = -999; /* would be initialized to 0 otherwise */

extern void doubleup(); /* declaration of a function defined in another file */

extern void print() { /* extern could be dropped from this definition */
  printf("global_num: %i\n", global_num);
}

/* set2zero can be invoked only by functions within this file */
static void set2zero() {
  global_num = 0;
}

int main() { /* extern could be added, but not necessary */
  doubleup(); /* function in another file */
  doubleup(); /* call doubleup() again */
  print();    /* -3996 */

  set2zero(); /* function in this file */
  print();    /* 0 */

  return 0;
}
