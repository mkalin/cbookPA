#include <stdio.h>

int main() {
  int n = 1234;   /* one variable named n */
  {
    int n = 9876; /* a distinct variable, same name as above */
    printf("%i\n", n);  /* 9876 */
  }
  printf("%i\n", n);    /* 1234 */
  return 0;
}

