#include <stdio.h>
#include <stdlib.h> /* rand() */

int main() {
  /* i and n are visible from their declaration to the end of main */
  auto int i; /* auto is the default in any case */
  int n = 10; /* auto as well */

  for (i = 0; i < n; i++) {
    register int r = rand() % 100; /* if no register available, auto */
    printf("%i ", r);
  } /* r goes out of scope here */
  putchar('\n'); /* instead of the usual printf("\n") */
  return 0;
}
