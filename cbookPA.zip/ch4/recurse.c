#include <stdio.h>

static const char* greeting[ ] = {NULL, "Hello", ", ", "world", "!\n"};
static unsigned ind = 4; /* 4 is the index of last string in the array */

int main() {
  /* base case: return on NULL */
  if (!greeting[ind]) return 0;

  /* recursive case: save current value of ind, decrement ind, and call main */
  unsigned i = ind--;          /* local copy per call to main */
  main();                      /* recursion */
  printf("%s", greeting[i]);   /* upon return, print your piece of the greeting */

  return 0;
}

