#include <stdio.h>

int main() {
  int n1 = 4, n2 = 11, n3 = 7;
  printf("%i\n", n1 + n2 * n3);     /*  81 */
  printf("%i\n", (n1 + n2) * n3);   /* 105 */
  printf("%i\n", n3 * n2 % n1);     /*   1 */
  printf("%i\n", n3 * (n2 % n1));   /*  21 */

  return 0;
}
