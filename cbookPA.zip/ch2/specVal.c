#include <stdio.h>
#include <math.h>

/** To compile: gcc -o ieee ieee.c -lm **/
int main() {
  printf("Sqrt of -1:    %f\n", sqrt(-1.0F));  /* 1 11111111 10000000000000000000000 */
  printf("Neg. infinity: %f\n", 1.0F / -0.0F);
  printf("Pos. ininitiy: %f\n", 1.0F / 0.0F);

  return 0;
}
