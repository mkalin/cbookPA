#include <stdint.h>
#include <stdio.h>

int main() {
  /* signed types, 8 through 64 bits; unsigned counterparts are uint8_t, etc. */
  size_t s1 = sizeof(int8_t);
  size_t s2 = sizeof(int16_t);
  size_t s3 = sizeof(int32_t);
  size_t s4 = sizeof(int64_t);
  printf("sizes from 8 through 64 signed: %lu %lu %lu %lu\n",
	 s1, s2, s3, s4); /* 1 2 4 8 */

  /* unsigned int big enough to hold at least 32 bits */
  s1 = sizeof(uint_least32_t);
  s2 = sizeof(int_least64_t);
  printf("sizes for at least 32 unsigned, at least 64 signed: %lu, %lu\n",
	 s1, s2); /* 4 8 */

  /* fast access */
  s1 = sizeof(int_fast32_t);
  printf("size for fast access in 32 bits signed: %lu\n", s1); /* 8 */

  /* maxes */
  s1 = sizeof(intmax_t);
  s2 = sizeof(uintmax_t);
  printf("sizes for signed/unsigned integer maxes: %lu %lu\n", 
	 s1, s2); /* 8 8 */
  
  return 0;
}
