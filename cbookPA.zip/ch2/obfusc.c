#include <stdio.h>
#include <limits.h> /* includes convenient min/max values for integer types */

int main() { /* void instead of int for some variety */
  unsigned int n = -1, m = UINT_MAX;          /* In 2's complement, -1 is all 1s */
  signed int k = 0xffffffff;                  /* 0x or 0X for hex: f is four 1s in hex */

  if (n == m) printf("m and n have the same value\n");  /* == compares bits: this prints */
  if (k == m) printf("m and k have the same value\n");  /* prints */

  printf("small as signed == %i,  small as unsigned == %u\n", n, n);  /* -1, 4294967295 */

  signed int small = -1;     /* signed converts to unsigned in mixed comparisons */
  unsigned int big = 98765;  /* comparing big and small is a mixed comparison */
  if (small > big) printf("yep, something's up...\n");

  return 0;
}
