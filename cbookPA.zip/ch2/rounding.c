#include <stdio.h>

int main() {
  /* 1.010000
     2.020000
     ...
     6.060000
     7.070001   ;; rounding up now evident
     8.080001   
     9.090001   
    10.100001   
  */
  float incr = 1.01f; 
  float num = incr;
  int i = 0;
  while (i++ < 10) {       /* i++ illustrates the post-increment operator */
    printf("%12f\n", num); /* %12f specifies the field width, not the decimal precision */
    num += incr;
  }
  return 0;
}
