#include <stdio.h>
#include <limits.h> /* INT_MAX */

int main() {
  printf("Max int in %lu bytes %i.\n", sizeof(int), INT_MAX); /* 4 bytes 2,147,483,647 */
  int n = 81;

  while (n > 0) {
    printf("%12i %12x\n", n, n);
    n *= n; /* n = n * n */
  }
  printf("%12i  %12x\n", n, n); /*  -501334399     e21e3e81 */
  return 0;
}
/*        81           51
        6561         19a1
    43046721      290d741
  -501334399     e21e3e81   ## e is 1101 in binary */
