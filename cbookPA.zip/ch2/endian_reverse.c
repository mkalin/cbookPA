#include <stdio.h>

unsigned int endian_reverse32(unsigned int n) { /* designed for 32 bits, or 4 bytes */
  return (n >> 24)          |  /* leftmost byte becomes rightmost */
    ((n << 8) & 0x00FF0000) |  /* swap the two inner bytes */
    ((n >> 8) & 0x0000FF00) |  /* ditto */
    (n << 24);                 /* rightmost byte becomes leftmost */
}

int main() {
  unsigned int n = 0x1234abcd;
  printf("Original: %x Reversed: %x\n", n, endian_reverse32(n));
  return 0;
}
