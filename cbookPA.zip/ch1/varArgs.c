#include <stdio.h>
#include <stdarg.h> /* va_list type, va_start va_arg va_end utilities */

double avg(int count, ...) { /* count is how many, ellipses are the other args */
  double sum = 0.0;
  va_list args;
  va_start(args, count); /* allocate storage for the additional args */
  int i;

  for (i = 0; i < count; i++) sum += va_arg(args, int); /* compute the running sum */
  va_end(args);          /* deallocate the storage for the list */
  if (count > 0) return sum / count;    /* compiler promotes count to double */
  else return 0;
}

int main() {
  printf("%f\n", avg(4, 1, 2, 3, 4));
  printf("%f\n", avg(9, 9, 8, 7, 6, 5, 4, 3, 2, 1));
  printf("%f\n", avg(0));

  return 0;
}
