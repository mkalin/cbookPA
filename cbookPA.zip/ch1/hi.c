#include <stdio.h>

int main() {
    /* msg is a pointer to a char, the H in Hello, world! */
    char* msg = "Hello, world!"; /* the string is implemented as an array of characters */
    printf("%s\n", msg);         /* %s formats the argument as a string */

    return 0;                    /* EXIT_SUCCESS */
}
