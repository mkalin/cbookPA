#include <stdio.h>

int add2(int n1, int n2) { /* definition: the body is enclosed in the braces */
   int sum = n1 + n2;      /* could avoid this step, kept here for verbosity */
   return sum;             /* ...could just return n1 + n2 */
}    

int main() {
    int k = -26, m = 44;
    int sum = add2(k, m); /* call the add2 function, save the returned value */

    /* %i means: format as an integer */
    printf("%i + %i = %i\n", k, m, sum); /* output: -26 + 44 = 18 */
    return 0; /* 0 indicates normal termination, < 0 indicates some error */
}
