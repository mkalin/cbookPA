#include <unistd.h>
#include <sys/syscall.h>

int main() {
  /* 0755: owner has read/write/execute permissions, others read/execute permissions */
  int perms = 0755; /* 0 indicates base-8, octal */
  int status = syscall(SYS_chmod, "/usr/local/website", perms);
  if (-1 == status) perror(NULL);
  return 0;
}
