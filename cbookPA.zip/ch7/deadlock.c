/** To compile: gcc -o deadlock deadlock.c -lpthread **/
#include<pthread.h>
#include<stdio.h>
#include<stdlib.h>

static pthread_mutex_t lock1, lock2; /** two locks protect the resource **/
static int resource = 0;             /** the resource **/

void grab_locks(const char* tname, const char* lock_name, const char* other_lock_name,
                pthread_mutex_t* lock, pthread_mutex_t* other_lock) {
  printf("%s trying to grab %s...\n", tname, lock_name);
  pthread_mutex_lock(lock);
  printf("%s grabbed %s\n", tname, lock_name);

  if (0 == strcmp(tname, "thread1")) usleep(100); /** fix is in! **/
  printf("%s trying to grab %s...\n", tname, other_lock_name);
  pthread_mutex_lock(other_lock);
  printf("%s grabbed %s\n", tname, other_lock_name);

  resource = (0 == strcmp(tname, "thread1")) ? -9999 : 1111;
  pthread_mutex_unlock(other_lock);
  pthread_mutex_unlock(lock);
}

void* thread1() {
  grab_locks("thread1", "lock1", "lock2", &lock1, &lock2); /* lock1...lock2 */
  return NULL;
}

void* thread2() {
  grab_locks("thread2", "lock2", "lock1", &lock2, &lock1); /* lock2...lock1 */
  return NULL;
}

int main(){
    pthread_t t1, t2;
    pthread_create(&t1, NULL, thread1, NULL);     /* start thread 1 */
    pthread_create(&t2, NULL, thread2, NULL);     /* start thread 2 */
    pthread_join(t1, NULL);                       /* wait for thread 1 */
    pthread_join(t2, NULL);                       /* wait for thread 2 */
    printf("Number: %i (Unlikely to print...)\n", resource); /* underscores the deadlock */

    return 0;
}
