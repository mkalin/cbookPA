#include <stdio.h>

#define Length 8
typedef int intV8 __attribute__ ((vector_size (Length * sizeof(int)))); /** critical **/

int main() {
  intV8 dataV1 = {1, 2, 3, 4, 5, 6, 7, 8};  /* no square brackets on dataV1 */
  intV8 dataV2 = {8, 7, 6, 5, 4, 3, 2, 1};  /* no square brackets on dataV2 */
  intV8 add = dataV1 + dataV2; /* 9  9  9  9  9  9  9 9 */  /* no loop */
  intV8 mul = dataV1 * dataV2; /* 8 14 18 20 20 18 14 8 */  /* no loop */
  intV8 div = dataV2 / dataV1; /* 8  3  2  1  0  0  0 0 */  /* no loop */

  int i;
  for (i = 0; i < Length; i++) printf("%i ", div[i]); /* square brackets return */
  putchar('\n');

  return 0;
}
