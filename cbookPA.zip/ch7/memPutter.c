#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void report_and_die() {
  perror(NULL);
  exit(-1);
}

char* setup_putter(key_t key, int byte_count, int flags) {
  /* Get the shared memory and its identifier. */
  int mem_id = shmget(key, byte_count, flags);
  if (mem_id < 0) report_and_die();

  char* mem_ptr = shmat(mem_id, NULL, 0); /* attach to putter's address space */
  if (mem_ptr == (void*) -1) report_and_die();
  return mem_ptr;
}

int main() {
  const char* greeting = "Hello, world!";  /* placed in shared memory */
  int len = strlen(greeting) + 1;          /* + 1 for the '\0' string terminator */

  key_t key = 9876;                        /* user-supplied key */
  char* mem_ptr = setup_putter(key, len, IPC_CREAT | 0666); /* 0666: read/write */
  memcpy(mem_ptr, greeting, len); /* copy the msg to shared memory */

  /* Hang around until the other process accesses the shared memory. */
  while ('H' == *mem_ptr)         /* other process will change 'H' to 'h' */
    sleep(1);
  puts("putter exiting...");

  return 0;
}
