#include <stdio.h>

int main(int argc, char* argv[ ]) {
  if (argc < 2) {
    puts("Usage: cline <one or more cmd-line args>");
    return;
  }
  puts(argv[0]);   /* executable program's name */
  int i;
  for (i = 1; i < argc; i++)
    puts(argv[i]); /* additional command-line arguments */
  printf("PID from cline is: %i\n", getpid());

  return 0;
}
