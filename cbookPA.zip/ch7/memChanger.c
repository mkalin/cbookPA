#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void report_and_die() {
  perror(NULL);
  exit(-1);
}

char* setup_changer(key_t key, int byte_count, int flags) {
  /* Get the shared memory and its identifier. */
  int mem_id = shmget(key, byte_count, flags);
  if (mem_id < 0) report_and_die("failed on shmget");

  /* Attach memory segment to changer's address space. */
  char* mem_ptr = shmat(mem_id, NULL, 0);
  if (mem_ptr == (void*) -1) report_and_die("failed on shmat");
  return mem_ptr;
}

int main() {
  int len = 14;      /* byte count of "Hello, world!" with '\0' included */
  char buffer[32];   /* leave some extra room for the string */
  memset(buffer, 0, sizeof(buffer)); /* clear out the buffer */
  key_t key = 9876;  /* user-supplied key */

  char* mem_ptr = setup_changer(key, len, 0666);
  *mem_ptr = 'h';  /* change the 'H' to 'h' as a signal to the putter */
  memcpy(buffer, mem_ptr, len); /* copy the msg from shared memory */
  puts(buffer);    /* print the string to confirm */

  return 0;
}
