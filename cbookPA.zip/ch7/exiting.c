#include <unistd.h>     /* symbolic constants */
#include <stdio.h>      /* printf, etc. */
#include <sys/wait.h>   /* waiting on process termination */
#include <stdlib.h>     /* utilities */

int main() {
  int status;                  /* parent captures child's status here */
  int cret = 0xaa11bb22;       /* child returns this value */

  pid_t cpid = fork();         /* spawn the child process */
  if (0 == cpid) {             /* fork() returns 0 to the child */
    printf("Child's pid and ppid: %i  %i\n", getpid(), getppid()); /* 2614 2613 */
    printf("Child returns %x explicitly.\n", cret);
    _exit(cret);               /* return an arbitrary value */
  }
  else { /* fork() returns new pid to the parent process */
    printf("Parent's pid: %i\n", getpid());   /* 2613 */
    printf("Waiting for child to exit\n");

    if (-1 != waitpid(cpid, &status, 0)) { /* wait for child to exit, store its status */
      if (WIFEXITED(status))
        printf("Normal exit with %x\n", WEXITSTATUS(status)); /** 22 **/
      else if (WIFSIGNALED(status))
        printf("Signaled with %x\n", WTERMSIG(status));
      else if (WIFSTOPPED(status))
        printf("Stopped with %x\n", WSTOPSIG(status)); /* stop pauses the process */
      else
        puts("peculiar...");
    }
    exit(0); /* parent exits with normal termination */
  }
  return 0;
}
