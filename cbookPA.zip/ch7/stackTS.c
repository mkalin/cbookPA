/* compilation: gcc -o stackTS stackTS.c -lpthread */
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

void error() {
  perror(NULL);  /* system error message */
  exit(-1);      /* abnormal termination */
}

void* print_t1(void* pn) {    /*** init function for thread1 ***/
  int* num_ptr1 = (int*) pn;  /* num_ptr and n point to the same place */
  *num_ptr1 += 10;            /* increment the number pointed to by 10 */
  printf("Thread1: %i\n", *num_ptr1); /* value is indeterminate */
  return NULL;
} /** implicit call to pthread_exit(...) **/

void* print_t2(void* n) {     /*** init function for thread2 ***/
  int* num_ptr2 = (int*) n;        
  *num_ptr2 *= 10;            /* increment 10-fold */
  printf("Thread2: %i\n", *num_ptr2); /* value is indeterminate */
  return NULL;
} /** implicit call to pthread_exit(...) **/

int main() {
  pthread_t t1, t2; /* the two threads */
  int num = 777;    /* threads t1 and t2 access num through pointers */

  /** Create and start two additional threads. **/
  int flag = pthread_create(&t1, NULL, print_t1, (void*) &num); 
  if (flag < 0) error();
  
  flag = pthread_create(&t2, NULL, print_t2, (void*) &num);     
  if (flag < 0) error();

  puts("main exiting...");
  /** main should call pthread_exit explicitly to allow other threads to continue **/
  pthread_exit(NULL);
  return 0;
}
