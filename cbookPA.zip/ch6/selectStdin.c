#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>

int main() {
  fd_set fds;                        /* set of file descriptors */
  struct timeval tv;
  int flag;
  char byte;

  FD_ZERO(&fds);                     /* clear the set of file descriptors */
  FD_SET(0, &fds);                   /* 0 == standard input */
  tv.tv_sec = 5;
  tv.tv_usec = 0;  

  flag = select(FD_SETSIZE, &fds, NULL, NULL, &tv); /* NULL writers, NULL exceptions */
  if (-1 == flag) 
    perror("select error");
  else if (flag) {                   /* flag == 1 == true */
    read(0, &byte, 1);               /* read the byte */
    printf("The byte's numeric value is: %i\n", byte);	
  }
  return 0;
}
