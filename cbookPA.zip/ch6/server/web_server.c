#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>

#define BuffSize 250

int main() {
  const int port = 3000;
  char request[BuffSize + 1];
  memset(request, 0, sizeof(request));
  struct sockaddr_in client_addr;
  socklen_t len = sizeof(struct sockaddr_in);

  fd_set active_set, temp_set;          /* temp_set becomes a copy of active_set */
  FD_ZERO(&active_set);                 /* clear the active_set */

  int sock_fd = get_servsocket(port);   /* get the original socket fd */
  FD_SET(sock_fd, &active_set);         /* add it to the set */
  fprintf(stderr, "Server awaiting connections on port %i.\n", port);

  while (1) {
    temp_set = active_set; /* make a working copy, as active_set changes */
    if (select(FD_SETSIZE, &temp_set, NULL, NULL, NULL) < 0)  /* activity? */
      report_and_exit("select(...)");

    int i;
    for (i = 0; i < FD_SETSIZE; i++) {       /* handle the current fds */
      if (!FD_ISSET(i, &temp_set)) continue; /* member of the set? */

      if (i == sock_fd) { /** original accepting socket **/
        int client_fd = accept(sock_fd,
                               (struct sockaddr*) &client_addr,
                               &len);
        if (-1 == client_fd) continue; /* try again */
        log_client(&client_addr.sin_addr);
        FD_SET(client_fd, &active_set); /* add this fd to select list */
      }
      else {              /** read/write socket **/
        int bytes_read = read(i, request, BuffSize);
        if (bytes_read < 0) continue;

        /* Send a response. */
        char response[BuffSize * 2]; /* twice as big to be safe */
        memset(response, 0, sizeof(response));
        get_response(request, response);
        int bytes_written = write(i, response, strlen(response));
        if (bytes_written < 0) report_and_exit("write(...)");
        close(i);

        FD_CLR(i, &active_set); /* remove from active set */
      }
    }
  }
  return 0;
}
