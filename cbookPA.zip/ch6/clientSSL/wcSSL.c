#include "wcSSL.h"
#define BuffSize 2048

int main() {
  const char* host_port = "www.google.com:443";
  const char* request = "GET / \r\nHost: www.google.com\r\nConnection: close\r\n\r\n";
  BIO* out = BIO_new_fp(stdout, BIO_NOCLOSE); /* standard output */
  SSL* ssl = NULL;                            /* primary data structure for SSL connect */

  load_SSL();
  const SSL_METHOD* method = SSLv23_method(); /* protocol version */
  if (NULL == method) report_exit("SSLv23_method()");
  SSL_CTX* ctx = SSL_CTX_new(method);         /* global context for client/server */
  if (NULL == ctx) report_exit("SSL_CTX_new(...)");

  BIO* web = BIO_new_ssl_connect(ctx);  /* BIO is roughly FILE, but with SSL baked in */
  if (NULL == web) report_exit("BIO_new_ssl_connect(...)");
  if (1 !=  BIO_set_conn_hostname(web, host_port)) report_exit("BIO_set_conn_host(...)");
  BIO_get_ssl(web, &ssl); /* the security layer atop HTTP */
  if (NULL == ssl) report_exit("BIO_get_ssl(...)");

  if (BIO_do_connect(web) <= 0) report_exit("BIO_do_connect(...)");     /* connect */
  if (BIO_do_handshake(web) <= 0) report_exit("BIO_do_handshake(...)"); /* handshake */
  SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER, verify_dc);
  if (!SSL_get_verify_result(ssl)) report_exit("SSL_get_verify(...)");  /* verify cert */
  view_cert(ssl, out);                                                  /* look at cert */

  BIO_puts(web, request);   /* the GET request */
  int len = 0;
  do {                      /* read chunks from Google server */
    char buff[BuffSize] = { };
    len = BIO_read(web, buff, sizeof(buff));
    if (len > 0) BIO_write(out, buff, len);
  } while (len > 0 || BIO_should_retry(web));

  cleanup(out, web, ctx);  /* free heap storage */

  return 0;
}
