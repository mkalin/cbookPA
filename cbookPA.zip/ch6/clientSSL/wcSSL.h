#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <openssl/bio.h>
#include <openssl/ssl.h>
#include <openssl/x509.h>
#include <openssl/x509_vfy.h>

void report_exit(const char* msg);
void load_ssl();
int verify_dc(int ver, X509_STORE_CTX* x509_ctx);
void view_cert(SSL* ssl, BIO* out);
void cleanup(BIO* out, BIO* web, SSL_CTX* ctx);
